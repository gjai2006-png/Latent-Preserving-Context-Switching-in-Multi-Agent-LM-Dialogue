# Error analysis examples (RL controller, test split)

80 joint successes and 80 failures out of 160 rollouts.

### success
- gold z (eval metadata): `teacher_gift`; private controller action: `road_trip`
- B's history:
```
A: The gift thing is due before Sunday, right?
B: Yes, that's the deadline.
A: Okay, we're on track then.
B: Great, let's keep it that way.
```
- A's post-switch message (public): "Hey there! Planning a road trip sounds like fun! Do you have any specific places in mind?"
- B decoder -> `teacher_gift`, B prompted -> `secret_santa`, C prompted -> `farewell_video` (raw: '2')

### success
- gold z (eval metadata): `secret_santa`; private controller action: `board_games`
- B's history:
```
A: I keep the gift thing notes on my phone now.
B: Smart, so you don't lose them.
A: Yeah, there are too many details.
B: Send me a copy just in case.
```
- A's post-switch message (public): "I've been thinking we should get together for a game night soon. Any recommendations?"
- B decoder -> `secret_santa`, B prompted -> `secret_santa`, C prompted -> `club_trivia` (raw: '3')

### failure (C recovered z)
- gold z (eval metadata): `secret_santa`; private controller action: `board_games`
- B's history:
```
A: I keep the gift thing notes on my phone now.
B: Smart, so you don't lose them.
A: Yeah, there are too many details.
B: Send me a copy just in case.
```
- A's post-switch message (public): "Hey, have you heard about our Secret Santa game? It's like playing a big game of Clue without any clues!"
- B decoder -> `secret_santa`, B prompted -> `secret_santa`, C prompted -> `secret_santa` (raw: '7')

### failure (B decoder wrong)
- gold z (eval metadata): `teacher_gift`; private controller action: `road_trip`
- B's history:
```
A: The gift thing is due before next weekend, right?
B: Yes, that's the deadline.
A: Okay, we're on track then.
B: Great, let's keep it that way.
```
- A's post-switch message (public): "C, have you planned our road trip yet? We're all excited!"
- B decoder -> `secret_santa`, B prompted -> `secret_santa`, C prompted -> `club_trivia` (raw: '3')

